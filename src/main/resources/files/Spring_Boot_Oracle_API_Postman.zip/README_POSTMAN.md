# Postman Setup

1. Start the Spring Boot application.
2. In Postman, click **Import**.
3. Import the collection JSON and environment JSON.
4. Select **Spring Boot Oracle API - Local**.
5. Run a request.

Default base URL: `http://localhost:8091`

Notes:
- Oracle-backed APIs need database connectivity and the expected Oracle objects.
- For Excel upload, manually choose the local `.xlsx` file.
- For PDF APIs, use **Send and Download**.
- SOAP and WSO2 requests require access to the services configured in the Java code.
